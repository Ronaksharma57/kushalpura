# CSS-Only text shader

A Pen created on CodePen.io. Original URL: [https://codepen.io/robb0wen/pen/KKoVOrq](https://codepen.io/robb0wen/pen/KKoVOrq).

